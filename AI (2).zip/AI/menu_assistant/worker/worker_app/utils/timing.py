"""Timing helpers."""
