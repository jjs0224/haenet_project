"""Hashing helpers."""
