"""Image read/write utilities."""
