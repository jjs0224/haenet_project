"""Shared exceptions."""
