"""ALG_* tag constants."""
