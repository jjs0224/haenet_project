"""Final result schema."""
